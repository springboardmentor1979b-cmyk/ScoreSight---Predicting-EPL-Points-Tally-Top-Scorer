import streamlit as st
import pandas as pd
import joblib

# Load saved models
best_reg = joblib.load("best_regressor.pkl")
best_clf = joblib.load("best_classifier.pkl")
position_encoder = joblib.load("position_encoder.pkl")  # optional

st.title("EPL Prediction App")

# Sidebar for navigation
page = st.sidebar.radio("Navigate to:", ["Match Outcome", "Player Performance"])

if page == "Match Outcome":
    st.header("Match Outcome Prediction (Win/No Win)")

    st.write("Enter match data:")
    appearances = st.number_input("Appearances", min_value=0, value=10)
    shots = st.number_input("Shots", min_value=0, value=5)
    passes = st.number_input("Passes", min_value=0, value=20)
    assists = st.number_input("Assists", min_value=0, value=2)
    age = st.number_input("Age", min_value=15, max_value=45, value=25)
    home_away = st.selectbox("Home/Away", ["Home", "Away"])
    home_away_encoded = 1 if home_away == "Home" else 0

    if st.button("Predict Match Outcome"):
        feature_cols_clf = ['Home_Away_encoded', 'Appearances', 'Shots', 'Passes', 'Assists', 'Age']
        X_input_clf = pd.DataFrame([{
            'Home_Away_encoded': home_away_encoded,
            'Appearances': appearances,
            'Shots': shots,
            'Passes': passes,
            'Assists': assists,
            'Age': age
        }], columns=feature_cols_clf)

        prediction = best_clf.predict(X_input_clf)[0]
        st.success(f"Predicted Outcome: {'Win' if prediction==1 else 'No Win'}")

if page == "Player Performance":
    st.header("Player Performance Prediction (Goals)")

    st.write("Enter player data:")
    appearances = st.number_input("Appearances", min_value=0, value=10, key='reg_app')
    shots = st.number_input("Shots", min_value=0, value=20, key='reg_shots')
    passes = st.number_input("Passes", min_value=0, value=100, key='reg_passes')
    assists = st.number_input("Assists", min_value=0, value=5, key='reg_assists')
    age = st.number_input("Age", min_value=15, max_value=45, value=25, key='reg_age')

    if st.button("Predict Goals"):
        feature_cols_reg = ['Appearances', 'Shots', 'Passes', 'Assists', 'Age']
        X_input_reg = pd.DataFrame([{
            'Appearances': appearances,
            'Shots': shots,
            'Passes': passes,
            'Assists': assists,
            'Age': age
        }], columns=feature_cols_reg)

        pred_goals = best_reg.predict(X_input_reg)[0]
        st.success(f"Predicted Goals: {pred_goals:.2f}")
